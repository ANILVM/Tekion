import boto3

segroup=input("enter security group name")
region=input("enter region name like ex:- us-east-1")
intype=input("enter instance type")
amid=input("Enter AMI ImageId")

client = boto3.client('ec2', region_name= region)

try:
    response = client.run_instances(
        BlockDeviceMappings=[
            {
                'DeviceName': '/dev/xvda',
                'Ebs': {

                    'DeleteOnTermination': True,
                    'VolumeSize': 20,
                    'VolumeType': 'gp2'
                },
            },
        ],
        ImageId= amid,
        InstanceType= intype,
        MaxCount=1,
        MinCount=1,
        Monitoring={
            'Enabled': False
        },
        SecurityGroupIds=[
            segroup,
         ],
        TagSpecifications=[
        {
            'ResourceType': 'instance',
            'Tags': [
                {
                    'Key': 'Env',
                    'Value': 'dev',
                },
                {
                    'Key': 'Name',
                    'Value': 'webserver',
                },
                {
                    'Key': 'Team',
                    'Value': 'development',
                }

            ],
        },
    ], 
    )
    print(response)   
except:
    print("exception occured")